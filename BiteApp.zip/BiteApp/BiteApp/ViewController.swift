//
//  ViewController.swift
//  BiteApp
//
//  Created by Gaida  on 09/10/2020.
//

import UIKit

class ViewController: UIViewController {

    // labels
    @IBOutlet weak var BinaryResultLabel: UILabel!
    @IBOutlet weak var label1: UILabel!
    
    // toggle buttons
    @IBOutlet weak var ZeroButton: UISwitch!
    @IBOutlet weak var OneButton: UISwitch!
    @IBOutlet weak var TwoButton: UISwitch!
    @IBOutlet weak var ThreeButton: UISwitch!
    @IBOutlet weak var FourButton: UISwitch!
    @IBOutlet weak var FiveButton: UISwitch!
    @IBOutlet weak var SixthButton: UISwitch!
    @IBOutlet weak var SeventhButton: UISwitch!
    
    //output view and fields
    @IBOutlet weak var DisplayTextView: UITextView!
    @IBOutlet weak var UserInputField: UITextField!
    
    
    var LightColor:UIColor = UIColor(hue: 51/360, saturation: 14/100, brightness: 94/100, alpha: 1.0)
    
    
    var result = 0.0
    var BinaryNumber = "00000000"
    
   
    
    override func viewDidLoad() {
            super.viewDidLoad()
        
            DisplayTextView.ApplyDesign()
            label1.textColor = LightColor
            BinaryResultLabel.textColor = LightColor
        
    // Add an action function of a UITextField
UserInputField.addTarget(self, action: #selector(ViewController.textFieldDidChange(_:)),
            for: .editingChanged)
       
    }
    
    
    

    @objc func textFieldDidChange(_ textField: UITextField) {
    /// call compare function if user made changes on the input field
        CompareNumber()
    }
    
   /// this function compute the value from it's position and base
    @IBAction func Switched(_ sender: Any) {
    guard let button = sender as? UISwitch else {
            return
        }
        if button.isOn {
        switch button.tag{
            case 0:
                result += pow(2,0)
                BinaryNumber = BinaryNumber.replaceAtIndex("1", at: 7)
            case 1:
                result += pow(2, 1)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 6)
            case 2:
                result += pow(2, 2)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 5)
            case 3:
                result += pow(2, 3)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 4)
            case 4:
                result += pow(2, 4)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 3)
            case 5:
                result += pow(2, 5)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 2)
            case 6:
                result += pow(2, 6)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 1)
            case 7:
                result += pow(2, 7)
                BinaryNumber =  BinaryNumber.replaceAtIndex("1", at: 0)
              
            default:
                print("nothing!")
            }
        }
        else{
            
            switch button.tag{
                case 0:
                    result -= pow(2,0)
                    BinaryNumber =     BinaryNumber.replaceAtIndex("0", at: 7)
                case 1:
                    result -= pow(2, 1)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 6)
                case 2:
                    result -= pow(2, 2)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 5)
                case 3:
                    result -= pow(2, 3)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 4)
                case 4:
                    result -= pow(2, 4)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 3)
                case 5:
                    result -= pow(2, 5)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 2)
                case 6:
                    result -= pow(2, 6)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 1)
                case 7:
                    result -= pow(2, 7)
                    BinaryNumber =    BinaryNumber.replaceAtIndex("0", at: 0)
                default:
                    print("nothing!")
                }
        }
        

        BinaryResultLabel.text = BinaryNumber
        DisplayTextView.text = String(Int(result))
    }
    
    
    
    //function makes comparsion between user input and the displayed number
    func CompareNumber(){
        if UserInputField.text == DisplayTextView.text{
            DisplayTextView.backgroundColor = LightColor
            DisplayTextView.textColor = .black
        } else{
           
            DisplayTextView.ApplyDesign()
        }
    }



}

// extension to TextView design
extension UITextView {
    func ApplyDesign(){
        self.clipsToBounds = true
        self.backgroundColor = UIColor(hue: 282/360, saturation: 34/100, brightness: 45/100, alpha: 1.0)
        self.layer.cornerRadius = 65.0
        
    }
  }

//Extension to String, with a replace function
extension String {
    func replaceAtIndex(_ with: String, at index: Int) -> String {
        var changedString = String()
            for (i, char) in self.enumerated() {
            changedString += String((i == index) ? with : String(char))
            }
        return changedString
    }
}
